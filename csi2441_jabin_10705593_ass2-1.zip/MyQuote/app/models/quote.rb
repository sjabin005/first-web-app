class Quote < ApplicationRecord
  belongs_to :user
  belongs_to :philosopher
  has_many :quote_categories, dependent: :destroy
  has_many :categories, through: :quote_categories
  validates :categories, presence: true 
  accepts_nested_attributes_for :philosopher
end
