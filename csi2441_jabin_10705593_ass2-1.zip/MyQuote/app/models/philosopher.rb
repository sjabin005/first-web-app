class Philosopher < ApplicationRecord
    has_many :quotes, dependent: :nullify
    validates :fname, presence: true 
end
