# manages CRUD operations for categories
class CategoriesController < ApplicationController
  # runs set_category before show, edit, update, destroy. Finds out the category that user wants to access.
  before_action :set_category, only: %i[show edit update destroy]

  # GET /categories or /categories.json
  # display all categories
  def index
    @categories = Category.all
  end

  # GET /categories/1 or /categories/1.json
  # display one category, the before_action finds it and then stores it in @category
  def show
  end

  # GET /categories/new
  # it creates new unsaved category which user created
  def new
    @category = Category.new
  end