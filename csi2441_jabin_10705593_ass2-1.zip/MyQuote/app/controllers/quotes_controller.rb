class QuotesController < ApplicationController 
  #runs set_quote before show,edit,update and destroy
  before_action :set_quote, only: %i[ show edit update destroy ]
  #Requires log in for every action except show 
  before_action :require_login, except: [:show]
  #only the owner can access these protected features
  before_action :require_owner, only: %i[edit update destroy]

  # Displays only logged in user's quote, so user will see only their own 
  def index
    @quotes = current_user.quotes
  end

  # GET /quotes/1
  def show
  end

  # Create a new quote and prepares an empty philosopher form 
  def new
    @quote = Quote.new
    @quote.build_philosopher   
  end

  # CHecks whether the quote form has philosopher if not prepares a philosopher object within the form 
  def edit
    @quote.build_philosopher unless @quote.philosopher
  end

  # POST /quotes
  def create
    #creates and saves a new quote and is referring to the quote_paramas
    @quote = Quote.new(quote_params)
    #assigns the quote with the currently logged in user id
    @quote.user_id = current_user.id  
    #checks whether the quote is saved successfully for that user
    respond_to do |format|
      if @quote.save
        #redirects to the quote page after quote has been created 
        format.html { redirect_to quote_url(@quote), notice: "Quote was successfully created." }
        format.json { render :show, status: :created, location: @quote }
      else
        #if saving fails, displays the form again 
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @quote.errors, status: :unprocessable_entity }
      end
    end
  end

  # updates the existing quote
  def update
    respond_to do |format|
      if @quote.update(quote_params)
        #redirects to the quote page after the update has been successful
        format.html { redirect_to quote_url(@quote), notice: "Quote was successfully updated." }
        format.json { render :show, status: :ok, location: @quote }
      else
        #displays the edit form again if the update is not saved successfully
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @quote.errors, status: :unprocessable_entity }
      end
    end
  end

  # Deletes the selected quote for the specific logged in user
  def destroy
    @quote.destroy
    #redirects to the quote page after successful deletion 
    respond_to do |format|
      format.html { redirect_to quotes_url, notice: "Quote was successfully destroyed." }
      format.json { head :no_content }
    end
  end



  private
#finds a quote using its ID
    def set_quote
      @quote = Quote.find(params[:id])
    end

#these features can be accessed by owner only, user is an owner when the current user id matches with the stored user id in session otherwise access denied
  def require_owner
    return if @quote.user_id==session[:user_id]
    flash[:error]="Access denied"
    redirect_to root_path
  end 
#allows only these approved fields to be submitted
    def quote_params
      params.require(:quote).permit(
        :qtext, 
        :qyear,
        :qcom,
        :ispublic,
        category_ids: [],
        philosopher_attributes: [:fname, :lname, :byear, :dyear, :bio]
      )
    end
end
