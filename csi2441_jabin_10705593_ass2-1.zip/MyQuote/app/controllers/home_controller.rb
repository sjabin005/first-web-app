class HomeController < ApplicationController
  # public home page shows top 10 recently added public quotes and order them newest first way
  def index
    @quotes = Quote.where(ispublic: true).order(created_at: :desc).take(10)
  end

  # retrives the logged in users quote so that user can see their own quote and display them in uquotes.html
  def uquotes
    @quotes = Quote.where(user_id: session[:user_id])
  end

  # Administrator landing page, shown after admin logs in
  def aindex
  end

  # Standard user landing page, shown after user logs in
  def uindex
  end
end

