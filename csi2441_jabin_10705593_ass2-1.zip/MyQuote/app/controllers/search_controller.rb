class SearchController < ApplicationController
  def index
    #gets the category name entered by user
    category_query = params[:category_query]
    #if user has typed something in the box
		if category_query.present?
    #finds a public quote where the category name matches with the search term
    #joins joins the category table with the quote and find out those quotes that are within the same category
    #distinct prevents duplicacy of same quote apperaing twie 
		  @quotematch = 
Quote.joins(:categories).where(ispublic: true).where("categories.catname LIKE ?", "%#{category_query}%").distinct
    end

  end
end
