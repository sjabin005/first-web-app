class SessionsController < ApplicationController
  # display login page
  def new
  end

  # rails finds out the user from database using provided information
  def create
    user = User.find_by(email: params[:email])

    # test these 3 conditions
    if user && user.authenticate(params[:password]) && user.status == "Active"
      # if the user email, password and active status is okay then it stores the users details in the current session
      session[:user_id] = user.id
      session[:fname] = user.fname
      session[:is_admin] = user.is_admin

      if session[:is_admin]
        # if the users role is admin then redirects user to admin landing page
        redirect_to admin_path, notice: "Logged in successfully!"
      else
        # otherwise if user is standard user, redirects the user to user landing page
        redirect_to userhome_path, notice: "Logged in successfully!"
      end
    else
      # otherwise if the login fails, shows error message and shows the login page again
      flash.now[:error] = "Invalid email or password. Please try again."
      render 'new', status: :unprocessable_entity
    end
  end

  # when the user logs out, it clears the current user session and all information regarding that user from the session and shows the log out message.
  def destroy
    session[:user_id] = nil
    session[:fname] = nil
    session[:is_admin] = nil
    session[:status] = nil

    redirect_to root_path, notice: "Logged out successfully!"
  end
end