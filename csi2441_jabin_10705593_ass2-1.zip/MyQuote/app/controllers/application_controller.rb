class ApplicationController < ActionController::Base
  # Only allow modern browsers supporting webp images, web push, badges, import maps, CSS nesting, and CSS :has.
  allow_browser versions: :modern
  

#Exposes these to view like navbar can  directly check login state and role 
  helper_method :current_user, :logged_in?, :is_administrator?

#Looks at currently logged in user from session, uses || so that the database is queried once  per request even if current_user is called multiple times. 
  def current_user
    @current_user ||= User.find_by(id: session[:user_id])
  end
#returns true if the user is logged in 
  def logged_in?
    !current_user.nil?
  end
#returns true if the logged in user is admin based on admin flag in session
  def is_administrator?
    session[:is_admin]
  end

  private
#Only authenticated user can access the protected page, logged out user cant access the role based features and user is redirected to login page,# The require_login method ensures that an action or controller is accessible only by
#logged-in users. If not logged in as determined by the logged_in? method, this method
#sets an error flash message and redirects the user to the login page. This method is
#applied as a before_action in controllers where some or all of the resident methods
#require authentication to be executed.
  def require_login
    unless logged_in?
      flash[:error] = "You are not permitted to access this resource"
      redirect_to login_path
    end
  end

end

