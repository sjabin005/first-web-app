class UsersController < ApplicationController
  # finds out the specific user before show, edit, destroy and update
  before_action :set_user, only: %i[show edit update destroy]

  # without new and create, every action needs log in
  before_action :require_login, except: [:new, :create]

  # before destroy action, check whether the user is admin
  before_action :require_admin, only: [:destroy]

  #unauthorised user or non quote owner cant see, edit, update others account or quote details 
  before_action :require_self_or_admin, only: %i[show edit update destroy]



  # if the user is logged in and admin then he can see all the users and their info
  def index
    if logged_in? && is_administrator?
      @users = User.all

    # otherwise, if the user is logged in but not admin, then is redirected ti user home page.
    elsif logged_in? && !is_administrator?
      redirect_to userhome_path
    else
      # otherwise, if the login fails, shows this error and redirects to login page
      flash[:error] = "You are not authorised to access this resource"
      redirect_to login_path
    end
  end

  def show
  end

  # creates an empty user object for new user
  def new
    @user = User.new
  end

  # GET /users/1/edit
  def edit
  end

  # user object is created using permitted fields
  def create
    @user = User.new(user_params)

    respond_to do |format|
      # if all required fields are provided and validation is done, tries to save the new user in database
      if @user.save
        # format.html { redirect_to @user, notice: "User was successfully created." }
        # if the user is saved successfully in the database means sign up is successful then user is redirected to log in page
        format.html { redirect_to login_path, notice: "Sign up successful. Please log in." }
        format.json { render :show, status: :created, location: @user }
      else
        # otherwise, if the sign up is not successful/user isnt saved properly, it shows the sign up page again
        format.html { render :new, status: :unprocessable_content }
        format.json { render json: @user.errors, status: :unprocessable_content }
      end
    end
  end

  # it updates the saved users data
  def update
    respond_to do |format|
      # changes the users details with the new information
      if @user.update(user_params)
        # if update successful, redirects to users detail page
        format.html { redirect_to @user, notice: "User was successfully updated.", status: :see_other }
        format.json { render :show, status: :ok, location: @user }
      else
        # otherwise shows the edit form again
        format.html { render :edit, status: :unprocessable_content }
        format.json { render json: @user.errors, status: :unprocessable_content }
      end
    end
  end

  # deletes the user from database
  def destroy
    @user.destroy!

    respond_to do |format|
      # if the user is deleted, redirects admin to users list
      format.html { redirect_to users_path, notice: "User was successfully destroyed.", status: :see_other }
      format.json { head :no_content }
    end
  end

  private

  # Use callbacks to share common setup or constraints between actions.
  def set_user
    # accepts ID from requests, and try to find the user from databse using the ID
    @user = User.find(params.expect(:id))
  end
#this prevents invading someones account , quote or editing them, it only shows them if the current user id is same as stored sessions user id otherwise denies access. 
  def require_self_or_admin
    return if is_administrator?|| @user.id==session[:user_id]
    flash[:error]="Access denied"
    redirect_to root_path
  end
  # Only allow a list of trusted parameters through.
  # determines which fields are accepted from the form
  def user_params
    params.expect(user: [:fname, :lname, :email, :password, :is_admin, :status])
  end

  

  # only logged in admins can cross this check, if the user isnt admin and not logged in then sends the user to home page.
  def require_admin
    unless logged_in? && current_user.is_admin
      redirect_to root_path
    end
  end
end
